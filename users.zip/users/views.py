# from typing_extensions import Required
from django.shortcuts import render, HttpResponseRedirect
from .forms import UserRegistrations
from .models import User

# Create your views here.

# /////////////////////////This function iss basically used to add and show data


def index(request):
    if request.method == 'POST':
        fm = UserRegistrations(request.POST)
        # easy way to save data in database
        # if fm.is_valid():
        #     fm.save()
        # Another cleaned way to save data in database
        if fm.is_valid():
            nm = fm.cleaned_data['name']
            em = fm.cleaned_data['email']
            pw = fm.cleaned_data['password']
            reg = User(name=nm, email=em, password=pw)
            reg.save()
            # //it use to blank our form after submit
            fm = UserRegistrations()
    else:
        fm = UserRegistrations()
    stud = User.objects.all()
    return render(request, 'index.html', {'form': fm, 'stu': stud})


# function will used to update data
def update_data(request, id):
    if request.method == 'POST':
        pi = User.objects.get(pk=id)
        fm = UserRegistrations(request.POST, instance=pi)
        if fm.is_valid():
            fm.save()
    else:
            pi = User.objects.get(pk=id)
            fm = UserRegistrations(instance=pi)
    return render(request, 'about.html', {'form': fm})


# ///////////////////////Function will used to delete the items

def delete_data(request, id):
    if request.method == 'POST':
        pi = User.objects.get(pk=id)
        pi.delete()
        return HttpResponseRedirect('/')
