# from random import choice
# from tkinter import CASCADE
from django.db import models
# from django.contrib.auth import UserRegistration, login

# Create your models here.


class User(models.Model):
    name = models.CharField(max_length=70)
    email = models.EmailField(max_length=100)
    password = models.CharField(max_length=100)
# choice = {
#     'Male': 'M'
#     'Female' :
# }

# 2 models create profile


# class profile(models.Model):
#     name = models.CharField(max_length = 50)
#     date = models.CharField(max_length = 50)
#     gender = models.CharField(max_length = 2)
#     phone = models.IntegerField()


# class address(models.Model):
#     name = models.OneToManyField(on_delete='')
#     address1 = models.CharField(max_length=100)
#     address2 = models.CharField(max_length = 100)
#     pincode = models.IntegerField()


# 3.  

# class UserRegistration(models.Model):
#     username = models.CharField(max_length = 20)
#     email = models.EmailField()
#     password = models.CharField(max_length=20)
#     password2 = models.CharField(max_length=20)


# class login(models.Model):
#     username = models.CharField(max_length = 20)
#     password = models.CharField(max_length = 20)
 








